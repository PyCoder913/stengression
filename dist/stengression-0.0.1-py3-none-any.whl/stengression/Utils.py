import numpy as np 
import pandas as pd 
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import typing
from typing import Optional
import torch.optim as optim
import typing
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import matplotlib.pyplot as plt
from scipy.stats import genpareto
import time
import warnings
warnings.filterwarnings('ignore')

# 1. Spatiotemporal dataset class.
class SpatioTemporalDataset(Dataset):
    def __init__(self, data, input_seq_len, output_seq_len, multi_horizon=True):
        """
        Spatio-temporal dataset for preparing lagged input sequences and forecast targets 
        from multivariate time series data.
        
        Args:
            data (torch.Tensor or np.ndarray): Time series data with shape (T_observed, num_nodes, num_features),
                where T_observed is number of time steps, num_nodes is number of nodes, and num_features is number of
                features per node.
            input_seq_len (int): Number of lagged time steps (p) to use as model input.
            output_seq_len (int): Number of future time steps (q) to predict.
            multi_horizon (bool, optional): If True, target output is the full forecast horizon sequence
                (q steps). If False, target is only the single next step after input_seq_len + output_seq_len offset.
        
        This dataset supports indexed access to input-output pairs suitable for training spatio-temporal
        forecasting models with sliding window sequences.
        """
        self.data = data
        self.input_seq_len = input_seq_len
        self.output_seq_len = output_seq_len
        self.multi_horizon = multi_horizon
        
        self.num_samples = data.shape[0] - (input_seq_len + output_seq_len) + 1

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        # idx is the index of the input sequence start
        # Input window: idx -> idx + input_seq_len, shape (input_seq_len, num_nodes, num_features)
        x = self.data[idx : idx + self.input_seq_len]
        
        # Output: sequence from end of input sequence to next output_seq_len steps
        if self.multi_horizon:
            y = self.data[idx + self.input_seq_len : idx + self.input_seq_len + self.output_seq_len]
        else:
            # If not multi_horizon, implement single step prediction
            y = self.data[idx + self.input_seq_len + self.output_seq_len]  # single step
        
        return x.float(), y.float()



# 3. Compute adjacency matrix from distances matrix.
def compute_adjacency_matrix(route_distances : np.ndarray, sigma2: float, epsilon: float, n=10000):
    """Computes the adjacency matrix from distances matrix. It uses the formula in https://github.com/VeritasYin/STGCN_IJCAI-18#data-preprocessing to
    compute an adjacency matrix from the distance matrix. The implementation follows that paper.

    Usage: compute_adjacency_matrix(states_distances, sigma2=0.75, epsilon=0.5)
    """
    n_states = route_distances.shape[0]
    states_distances_norm = route_distances / n
    w2, w_mask = (states_distances_norm * states_distances_norm, np.ones([n_states, n_states]) - np.identity(n_states))

    return (np.exp(-w2 / sigma2) >= epsilon) * w_mask


# 4. Prepare spatial weights for SEN.
def prepare_spatial_weights(W, max_lag):
    """
    Pre-computes the powers of the spatial weight matrix W.

    Args:
        W (torch.Tensor): The base N x N spatial weight matrix.
        max_lag (int): The maximum spatial lag L.

    Returns:
        list of torch.Tensor: A list.
    """
    W_list =[torch.eye(W.shape[0])] # W^0 is the identity matrix
    W_pow = W
    for _ in range(max_lag):
        W_list.append(W_pow)
        W_pow = torch.matmul(W_pow, W)
    return W_list


# 5. Plotting helper function. Takes in an ensemble of forecasts and plots the original values and forecasted values along with CIs.
def plot_forecasts(num_nodes, plots_per_row, T_PRED, forecast_ensemble, ground_truth, confidence_level=0.95, node_names=None,
                   title='Forecast vs Actual with Confidence Interval', savefig=False, filename=None):
    """
    Plots forecasted time series against actual ground truth values for multiple nodes, including prediction intervals.

    Parameters:
    -----------
    num_nodes : int
        Number of nodes (time series) to plot.
    plots_per_row : int
        Number of subplots to display per row in the figure.
    T_PRED : int
        Number of timesteps in the forecast horizon.
    forecast_ensemble : torch.Tensor
        Ensemble of forecast samples with shape (m_samples, T_PRED, num_nodes) or compatible.
        Used to compute the median forecast and prediction intervals.
    ground_truth : torch.Tensor
        Actual observed values with shape (T_PRED, num_nodes).
    confidence_level : float, optional (default=0.95)
        Confidence level for the prediction intervals. For example, 0.95 corresponds to 95% intervals.
    node_names : list of str or None, optional
        Optional list of names for each node. If None, nodes are titled by their index.
    title : str, optional
        Overall title for the entire plot.

    Functionality:
    --------------
    - Computes the median forecast across the ensemble samples for each node and timestep.
    - Calculates lower and upper quantiles for the prediction interval based on the specified confidence level.
    - Creates a grid of subplots with each subplot showing:
        * Ground truth data as points connected by lines.
        * Median forecast as a line with markers.
        * Shaded confidence interval area between lower and upper prediction bounds.
    - Includes legends, axis labels, and titles distinguishing each node.

    Displays:
    ---------
    A matplotlib figure with subplots showing forecast versus actual data over the forecast horizon,
    with prediction intervals at the specified confidence level for each node.

    Note:
    -----
    The forecast_ensemble tensor is expected to contain multiple forecast samples that allow 
    quantile-based uncertainty estimation. All inputs must be compatible torch tensors with 
    appropriate shapes for reshaping within the function. While general forecast_ensemble can be of size
    (m_samples, T_PRED, num_nodes, num_features), this function is basic and expects only one feature per node,
    i.e. (m_samples, T_PRED, num_nodes) or (m_samples, T_PRED, num_nodes, 1).
    """
    
    num_rows = int(np.ceil(num_nodes / plots_per_row))
    fig, axs = plt.subplots(num_rows, plots_per_row, figsize=(20, 4 * num_rows), 
                            sharex=True, sharey=False)
    
    if num_nodes == 1:
        axs = [axs]
    else:
        axs = axs.flatten()
    
    timesteps = np.arange(1, T_PRED + 1)
    
    forecast_median = torch.median(forecast_ensemble, dim=0).values.view((T_PRED, num_nodes))
    forecast_median = torch.clamp(torch.round(forecast_median), min=0)
    lower_bound = torch.quantile(forecast_ensemble, 0.025, dim=0).view((T_PRED, num_nodes))
    lower_bound = torch.clamp(lower_bound, min=0)
    upper_bound = torch.quantile(forecast_ensemble, 0.975, dim=0).view((T_PRED, num_nodes))
    upper_bound = torch.clamp(upper_bound, min=0)
    
    for node in range(num_nodes):
        ax = axs[node]
        # Assigning lines to variables to extract handles later
        line1, = ax.plot(timesteps, ground_truth[:, node].cpu(), marker='o', 
                         label='Actual', markersize=4, color='black')
        line2, = ax.plot(timesteps, forecast_median[:, node].cpu(), marker='+', 
                         label='Forecasted', color='blue')
        fill = ax.fill_between(timesteps,
                               lower_bound[:, node].cpu(),
                               upper_bound[:, node].cpu(),
                               color='gray', alpha=0.3, label='95% CI')
        
        ax.set_title(node_names[node] if node_names else f'Node {node+1}')
        ax.grid(alpha=0.5)

    # Remove unused subplots
    for i in range(num_nodes, len(axs)):
        fig.delaxes(axs[i])
    
    # Global labels
    fig.suptitle(title, fontsize=16)

    # Create a single legend at the bottom center
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=3, 
               fontsize='large', frameon=True, bbox_to_anchor=(0.5, 0.04))
    
    # Adjust layout: we increase the bottom margin (0.07) to fit the new legend
    plt.tight_layout(rect=[0, 0.07, 1, 0.97])
    if savefig and (filename is not None):
        plt.savefig(filename, format='pdf')
    plt.show()





import numpy as np 
import pandas as pd 
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import typing
from typing import Optional
import torch.optim as optim
import typing
import warnings
warnings.filterwarnings('ignore')


# 1. Energy score loss.

def energy_score_loss(y_true, y_pred_samples):
    """
    Calculates the Energy Score loss.
    Args:
        y_true (torch.Tensor): Shape (B, t_pred, N, D)
        y_pred_samples (torch.Tensor): Shape (M, B, t_pred, N, D), M = number of samples or trajectories
    """
    M, B, T, N, D = y_pred_samples.shape
    y_pred_samples = y_pred_samples.permute(1,0,2,3,4) # (B, M, T, N, D)
    y_true_expanded = y_true.unsqueeze(1) # (B, 1, T, N, D)

    # First term: E||Y_hat - y||
    # First, the difference (y_pred_samples - y_true_expanded) computes element-wise differences between each predicted sample and the true value.
    # torch.norm(..., p=2, dim=(-3, -2, -1)): Computes the Euclidean (L2) norm of the difference over the last three dimensions (T, N, D). 
    # This gives a norm per batch and sample, measuring how far each predicted sample is from the true sequence in Euclidean distance.
    # .mean(dim=1): Averages this norm over the M samples dimension, resulting in one average distance per batch.
    term1 = torch.norm(y_pred_samples - y_true_expanded, p=2, dim=(-3, -2, -1)).mean(dim=1)

    if M > 1:
        # Second term: 0.5 * E||Y_hat - Y_hat'||
        # Reshape for pairwise distance calculation
        y_pred_flat = y_pred_samples.view(B, M, -1) # -> (B, M, T*N*D)
        
        # Calculate pairwise distances
        dist_matrix = torch.cdist(y_pred_flat, y_pred_flat, p=2)
        term2 = 0.5 * dist_matrix.mean(dim=(1, 2))
        return (term1 - term2).mean()

    return term1.mean()

# 2. Energy score + MSE
def EnergyMSELoss(y_true, y_pred_samples, lambda_mse=0.5):
    """Combines Energy Score and MSE loss."""
    eng_loss = energy_score_loss(y_true, y_pred_samples)
    y_pred_samples=y_pred_samples.permute(1,0,2,3,4) # (B, M, T, N, D)
    y_pred_mean = y_pred_samples.mean(dim=1)
    mse_loss = nn.MSELoss()(y_pred_mean, y_true)
    
    return torch.abs(eng_loss + lambda_mse * mse_loss)
